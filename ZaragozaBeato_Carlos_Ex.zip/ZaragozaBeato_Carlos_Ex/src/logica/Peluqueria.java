/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import java.util.logging.Level;
import java.util.logging.Logger;
import zaragozabeato_carlos_ex.ZaragozaBeato_Carlos_Ex;

/**
 *
 * @author usumaniana
 */
public class Peluqueria {

    private int numero_sillas_espera;
    private int numero_sillas_ocupadas = 0;
    private boolean silla_barbero_ocupada = false;
    private boolean corte_terminado = false;
    private boolean peluquero_dormido = false;

    public Peluqueria() {
        this.numero_sillas_espera = ZaragozaBeato_Carlos_Ex.numero_sillas;
    }

    /**
     * MEtodo que comprueba primero si tenemos espacio en nuestra peluqueria, i
     * no hay el metodo termina y el cliente se va sin cortarse el pelo. Sin
     * embargao si el metodo no se termina entonces comprobamos si la peluquera
     * esta ocupa, si lo esta hacemos esperar al hilo, si no lo esta seguimos
     * con la ejecucion de nuestro programa, donde deberemos restar un cliente
     * de nuestra sala de espera ya que hemos pasado a un cliente a la silla de
     * la peluquera, y volveremos hacer esperar a nuestra peluquera mientras
     * realiza el corte de pelo, y ya por ultimo notificaremos todos los hilos.
     *
     * @param identificador
     * @return
     */
    public synchronized boolean EntrarPeluqueria(String identificador) {
        if (numero_sillas_ocupadas == numero_sillas_espera) {
            System.out.println("---- El cliente " + identificador + " se va sin cortarse el pelo");
            return false;
        } else {

            numero_sillas_ocupadas++;
            System.out.println("---- El cliente " + identificador + " se sienta en la silla de espera");
            while (silla_barbero_ocupada) {
                try {
                    wait();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Peluqueria.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            numero_sillas_ocupadas--;

            silla_barbero_ocupada = true;
            corte_terminado = false;

            if (peluquero_dormido) {
                System.out.println("---- El cliente " + identificador + " despierta a la peluquera");
                notifyAll();
            }
            
            System.out.println("---- El cliente " + identificador + " en la silla de la peluquera");
            while (!corte_terminado) {
                try {
                    wait();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Peluqueria.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            silla_barbero_ocupada = false;
            notifyAll();

            System.out.println("---- El cliente " + identificador + " se va con el pelo cortado");
            return true;
        }
    }

    /**
     * Este metodo pone a dormir a nuestra peluquera, y comprobamos si tenemos
     * ocupada la silla de corte de pelo, si no este ocupa resulta que la
     * peluquera esta cortando el pelo
     *
     * @throws InterruptedException
     */
    public synchronized void EsperarCliente() throws InterruptedException {

        peluquero_dormido = true;
        while (!silla_barbero_ocupada) {
            System.out.println("++++ PELUQUERA esperando cliente");
            wait();
        }
        peluquero_dormido = false;
        System.out.println("++++ PELUQUERA cortando el pelo");
    }

    /**
     * Metodo para notificar que nuestra peluquera ha terminado de cortar el
     * pelo
     */
    public synchronized void AcabarCorte() {
        corte_terminado = true;
        System.out.println("++++ PELUQUERA termina de cortar el pelo");
        notifyAll();
    }

}
