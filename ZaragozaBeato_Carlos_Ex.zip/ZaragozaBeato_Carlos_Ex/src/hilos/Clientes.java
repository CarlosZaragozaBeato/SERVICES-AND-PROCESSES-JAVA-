/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hilos;

import logica.Peluqueria;


/**
 *
 * @author usumaniana
 */
public class Clientes extends Thread {

    private Peluqueria peluqueria;
    private boolean cortePelo = false;

    public Clientes(Peluqueria peluqueria) {
        this.peluqueria = peluqueria;
    }

    /**
     * Hacemos que entre nuestro cliente a la peluqueria,y comprobamos con ese 
     * metodo si nuestras sillas de espera estan todas ocupadas. Si devolvemos false
     * y con ese false en la sentencia siguientes sabremos si nuestro cliente a entrado/tiene 
     * el pelo cortado para hacerlo espera 30 segudos mientras le crece el pelo, o 5seg lo q tarda en dar
     * una vuelta
     */
    public void run() {
        while (true) {
            try {
                Thread.sleep(2000);
                cortePelo = peluqueria.EntrarPeluqueria(this.getName());

                if (cortePelo) {  
                    Thread.sleep(30000);
                } else {
                    Thread.sleep(5000);
                }
            } catch (InterruptedException e) {System.out.println(e.getMessage());}
            
        }
    }

}
