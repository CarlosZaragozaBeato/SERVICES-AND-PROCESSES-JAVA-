/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hilos;

import java.util.logging.Level;
import java.util.logging.Logger;
import logica.Peluqueria;


/**
 *
 * @author usumaniana
 */
public class Peluquera extends Thread{

   	private Peluqueria peluqueria;

	public Peluquera(Peluqueria peluqueria) {
		this.peluqueria = peluqueria;
	}

        
        /**
         * llamamos al metodo de la peluqueria esperar cliente para comprobar si la 
         * peluquera esta cortando el pelo a un cliente o esta libre,
         * y llamamos al metodo de acaba el corte despues de los 5seg que dura dicho corte
         */
	public void run() {
		while (true) {
                    
                    try {
                        peluqueria.EsperarCliente();
                        
                        Thread.sleep(5000);
                        peluqueria.AcabarCorte();
                        
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) { System.out.println(ex.getMessage()); }
                   
	
		}
	}
    
    
    
}
