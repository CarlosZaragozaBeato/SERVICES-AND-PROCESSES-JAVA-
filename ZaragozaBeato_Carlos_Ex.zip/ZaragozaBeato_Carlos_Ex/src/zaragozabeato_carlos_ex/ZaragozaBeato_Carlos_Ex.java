/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package zaragozabeato_carlos_ex;

import hilos.Clientes;
import hilos.Peluquera;
import logica.Peluqueria;

/**
 *
 * @author usumaniana
 */
public class ZaragozaBeato_Carlos_Ex {

    /**
     * @param args the command line arguments
     */
    
    /**
     * Modificando estas dos variables podremos cambiar globalmente los parametros de nuestra aplicacion
     */
    public static final int numero_sillas = 4;
    public static final int numero_Clientes = 10;

    public static void main(String[] args) {

        Peluqueria peluqueria = new Peluqueria();
        Peluquera peluquera = new Peluquera(peluqueria);
        

        peluquera.start();

        for (int i = 0; i < numero_Clientes; i++) {
            Clientes cl  = new Clientes(peluqueria);
            cl.setName(i+"");
            cl.start();
        }

    }

}
